import os
import threading
import time
import ctypes

#caption bar thing idfk
ctypes.windll.kernel32.SetConsoleTitleW("Pythia")

from os import environ
environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'

import pygame  # it is important to import pygame after that

def play_music(file_path):
    pygame.mixer.music.load(file_path)
    pygame.mixer.music.play()

    # get how long song is
    try:
        audio = pygame.mixer.Sound(file_path)
        dur = audio.get_length()
    except:
        dur = 0
    
    # convert to m and s
    dur_min = int(dur / 60)
    dur_sec = int(dur % 60)
    dur_formatted = f"{dur_min:02d}:{dur_sec:02d}"

    paused = False
    save_state = None

    while pygame.mixer.music.get_busy():
        if not pygame.display.get_init():
            pygame.display.init()

        time.sleep(0.01)
        progress = pygame.mixer.music.get_pos() / 1000

        # convert progress to m and s
        prog_min = int(progress / 60)
        prog_sec = int(progress % 60)
        prog_formatted = f"{prog_min:02d}:{prog_sec:02d}"

        # progress bar math wow
        progress_percent = progress / dur * 100
        bar_filled = int(progress_percent / 10)
        bar_empty = 10 - bar_filled
        progress_bar = f"[{'=' * bar_filled}{' ' * bar_empty}]"

        # progress bar being shown
        print(f"\r{progress_bar} {{ {prog_formatted} / {dur_formatted} }}", end="")
        
        if not paused and pygame.key.get_pressed()[pygame.K_p]:
            paused = True
            save_state = pygame.mixer.music.get_pos()
            pygame.mixer.music.pause()
            print(f"\n{file_path} is paused.")
            
        elif paused and pygame.key.get_pressed()[pygame.K_p]:
            paused = False
            pygame.mixer.music.unpause()
            pygame.mixer.music.set_pos(save_state)
            print(f"\n{file_path} is playing.")

def main():
    # show basic intro
    print('Made by Bambus - https://bambus.lol')
    print('Welcome to Pythia, a Python-based CLI music player.')
    print('WE ONLY SUPPORT MP3 and WMA.')
    

    # what music files show
    print('List of music files:')
    music_files = os.listdir('music')
    for i, file in enumerate(music_files):
        print(f'{i+1}. {file}')

    # what file number, play music
    file_num = int(input('Enter a file number: '))
    file_path = os.path.join('music', music_files[file_num-1])
    print(f'Playing: {file_path}')
    pygame.mixer.init()
    pygame.display.set_caption(f'Pythia - {file_path}')
    music_thread = threading.Thread(target=play_music, args=(file_path,))
    music_thread.start()

if __name__ == '__main__':
    main()
